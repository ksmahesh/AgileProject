<!DOCTYPE html>
<html>
<head>
	<title>Spades Game</title>
	
	<!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	 <!--Linking the style sheet-->
	<link rel="stylesheet" type="text/css" href="style/style.css">
</head>
<body>
<!--
Container with complete layout.
The layout of the web page is divided into 3 rows and 3 columns. 
-->
<div class="container">

<!--Row1-->
<div class="row" style="height:35%; display: block;">
<!--Row1-column 1 -->
<div class="col-sm-4 col-md-4 col-lg-4">	
</div>
<!--Row1-column2-->
<!--Player in the north-->
<div class="col-sm-4 col-md-4 col-lg-4" style="background-color:red">
	<h3>Sam</h3>
	<div>
			<p style="font-size:20px">0/0</p>
		</div>
	<img src="images/player1.jpg" style="width:150px;height:150px">
</div>
<!--Row1 Column3-->
<div class="col-sm-4 col-md-4 col-lg-4">
</div>
</div>

<!--Row2-->
<div class="row" style="height:35%; display: block;">
<!--Row2-column 1 -->
<!--Player in the west-->
<div class="col-sm-4 col-md-4 col-lg-4" style="background-color:red">
<h3>Tim</h3>
<div>
			<p style="font-size:20px " align="centre">0/0</p>
		</div>
<img src="images/player1.jpg" style="width:150px;height:150px">
</div>
<!--Row2-column2-->
<div class="col-sm-4 col-md-4 col-lg-4">	
</div>
<!--Row2 Column3-->
<!--Player in the East-->
<div class="col-sm-4 col-md-4 col-lg-4" style="background-color:red">
<h3>Garry</h3>	
<div>
			<p style="font-size:20px">0/0</p>
		</div>
<img src="images/player1.jpg" style="width:150px;height:150px">
</div>
</div>

<!--Row3-->
<div class="row" style="height:30%; display: block;">
<!--Row3-column 1 -->
<div class="col-sm-4 col-md-4 col-lg-4">	
</div>
<!--Row3-column2-->
<!--Player in the south/Human Player-->
<div class="col-sm-4 col-md-4 col-lg-4" style="background-color:red">
	<h3>Mark</h3>
	<div>
			<div style="float:left; width:100px">
			<p style="font-size:20px">0/0</p>
			</div>
			<div style="">
			<img class="dealer" src="images/dealer.png"></img>
			</div>
		</div>
	<img src="images/human.jpg" style="width:150px;height:150px">
</div>
<!--Row3-column3-->
<div class="col-sm-4 col-md-4 col-lg-4">	
</div>
</div>

<!--Row4-->
<div class="row" style="height:10%; display: block;">
<!--Row4-column 1 -->
<div class="col-sm-0.5 col-md-0.5 col-lg-0.5">	
</div>
<!--Row4-column2-->
<!--Cards of Player-->
<div class="col-sm-11 col-md-11 col-lg-11" >
	<img src="images/dood_deck/101.gif" style="width:75px;height:75px">
	<img src="images/dood_deck/120.gif" style="width:75px;height:75px">
	<img src="images/dood_deck/131.gif" style="width:75px;height:75px">
	<img src="images/dood_deck/125.gif" style="width:75px;height:75px">
	<img src="images/dood_deck/110.gif" style="width:75px;height:75px">
	<img src="images/dood_deck/134.gif" style="width:75px;height:75px">
	<img src="images/dood_deck/127.gif" style="width:75px;height:75px">
	<img src="images/dood_deck/133.gif" style="width:75px;height:75px">
	<img src="images/dood_deck/105.gif" style="width:75px;height:75px">
	<img src="images/dood_deck/123.gif" style="width:75px;height:75px">
	<img src="images/dood_deck/138.gif" style="width:75px;height:75px">
	<img src="images/dood_deck/108.gif" style="width:75px;height:75px">
	<img src="images/dood_deck/145.gif" style="width:75px;height:75px">
</div>
<!--Row4-column3-->
<div class="col-sm-0.5 col-md-0.5 col-lg-0.5">	
</div>
</div>


</div>
</body>
</html>